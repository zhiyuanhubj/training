#!/usr/bin/env bash
# 一键安装 megatron-sft env 的所有依赖
#
# 前置：
#   - python 3.10 的 conda env 已创建：
#     conda create -n megatron-sft python=3.10 -y
#   - 机器上 nvidia-driver + CUDA 12.x 可用
#
# 用法:
#   bash scripts/00_install_env.sh           # 装基础环境（不装 apex）
#   bash scripts/00_install_env.sh apex      # 额外编译 apex (~30 min；mcore≥0.16 不强依赖)
#
# 环境变量（可覆盖）:
#   CONDA_ENV_NAME   conda env 名（默认 megatron-sft）
#   CONDA_BASE       miniconda 安装目录（默认从 `conda info --base` 自动探测）
#   CUDA_HOME        CUDA 路径（默认 /usr/local/cuda-12.8）

set -euo pipefail

# ----------------------------------------------------------------------
# 0. 自动探测 PROJECT_ROOT + 激活 env
# ----------------------------------------------------------------------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" && pwd)"
PROJECT_ROOT="${PROJECT_ROOT:-$(cd "${SCRIPT_DIR}/.." && pwd)}"
DEPS_DIR="${PROJECT_ROOT}/.deps"
mkdir -p "$DEPS_DIR"

CONDA_ENV_NAME="${CONDA_ENV_NAME:-megatron-sft}"
CONDA_BASE="${CONDA_BASE:-$(conda info --base 2>/dev/null || echo /opt/miniconda3)}"
# shellcheck disable=SC1091
source "${CONDA_BASE}/etc/profile.d/conda.sh"
conda activate "${CONDA_ENV_NAME}"

py_ver=$(python -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo "[install] python=$py_ver, env=$CONDA_DEFAULT_ENV"

# ----------------------------------------------------------------------
# 1. 校验 torch 已装
# ----------------------------------------------------------------------
if ! python -c 'import torch' >/dev/null 2>&1; then
    echo "[install] torch 未装，先装 torch 2.8.0+cu128 ..."
    pip install --upgrade 'torch==2.8.0' 'torchvision' \
        --index-url https://download.pytorch.org/whl/cu128
fi
python -c 'import torch; print("[install] torch:", torch.__version__, "cuda:", torch.version.cuda)'

# ----------------------------------------------------------------------
# 2. flash-attn (prebuilt wheel)
#    注意：torch 2.8.0+cu128 是 cxx11abi=TRUE 编译的，必须装匹配的 wheel，
#    否则会报 undefined symbol 错。pip install flash-attn 默认装的可能是 abiFALSE。
# ----------------------------------------------------------------------
FA_WHEEL="https://github.com/Dao-AILab/flash-attention/releases/download/v2.8.3/flash_attn-2.8.3+cu12torch2.8cxx11abiTRUE-cp310-cp310-linux_x86_64.whl"
need_install_fa=0
if ! python -c 'import flash_attn' >/dev/null 2>&1; then
    need_install_fa=1
else
    # 已装但 ABI 不对
    if ! python -c 'from flash_attn.flash_attn_interface import flash_attn_func' >/dev/null 2>&1; then
        echo "[install] flash-attn 已装但 ABI 不匹配，重装 ..."
        pip uninstall -y flash-attn || true
        need_install_fa=1
    fi
fi
if [[ "$need_install_fa" == "1" ]]; then
    echo "[install] 装 flash-attn 2.8.3 (cxx11abiTRUE) ..."
    pip install --no-build-isolation "$FA_WHEEL"
fi
python -c 'import flash_attn; from flash_attn.flash_attn_interface import flash_attn_func; print("[install] flash_attn:", flash_attn.__version__, "ok")'

# ----------------------------------------------------------------------
# 3. transformers (主分支，含 PR #43830 对 qwen3_5 支持)
# ----------------------------------------------------------------------
echo "[install] 装 transformers 主分支 ..."
pip install -U 'git+https://github.com/huggingface/transformers.git@main'
python -c 'import transformers; print("[install] transformers:", transformers.__version__)'

# ----------------------------------------------------------------------
# 4. ms-swift (主分支)
# ----------------------------------------------------------------------
echo "[install] 装 ms-swift 主分支 ..."
if [[ ! -d "${DEPS_DIR}/ms-swift" ]]; then
    git clone --depth=1 https://github.com/modelscope/ms-swift.git "${DEPS_DIR}/ms-swift"
else
    (cd "${DEPS_DIR}/ms-swift" && git pull --ff-only || true)
fi
pip install -e "${DEPS_DIR}/ms-swift[all]"
python -c 'import swift; print("[install] swift:", swift.__version__)'

# ----------------------------------------------------------------------
# 5. 训练相关基础
# ----------------------------------------------------------------------
pip install -U \
    'accelerate>=1.10.0' \
    'peft>=0.17.0' \
    'trl>=0.20.0' \
    'datasets>=3.6.0' \
    'deepspeed>=0.15.0' \
    'modelscope' \
    'einops' 'sentencepiece' 'tiktoken' \
    'tensorboard' 'swanlab' \
    'rich' 'tqdm' 'ipython' \
    'decord' 'qwen_vl_utils' 'huggingface_hub'   # qwen3.5 多模态 / 下载工具

# ----------------------------------------------------------------------
# 6. flash-linear-attention (GatedDeltaNet 内核) + tilelang
#    tilelang 必装：Triton >= 3.4 + Hopper GPU (H100/H200) 上 fla 的
#    gated chunk_bwd_dqkwg 会产生错误结果（fla bug #640），fla 检测到此场景
#    会 raise 错误，必须用 tilelang 后端替代。
# ----------------------------------------------------------------------
echo "[install] 装 flash-linear-attention + tilelang ..."
pip install -U 'flash-linear-attention' 'tilelang'
python -c 'from fla.ops.gated_delta_rule import chunk_gated_delta_rule; import tilelang; print("[install] fla + tilelang ok")'

# ----------------------------------------------------------------------
# 7. Megatron 后端依赖
#    - megatron-core / mcore-bridge: pip wheel，秒装
#    - transformer_engine (TE): 需要 nccl.h 才能编译 frontend；编译约 1-2 min
#    - apex: 源码编译 30+ min，且 mcore>=0.16 不强依赖（缺失会 fallback 到 Torch Norm
#            略慢但功能完整）。所以默认不装。想装：bash scripts/00_install_env.sh apex
# ----------------------------------------------------------------------
echo "[install] 装 megatron-core + mcore-bridge ..."
pip install --no-deps -U megatron-core mcore-bridge

# transformer_engine
if ! python -c 'import transformer_engine.pytorch' >/dev/null 2>&1; then
    echo "[install] 装 transformer_engine[pytorch,core_cu12] ... (~1 min 编译)"
    # 设置 NCCL 头路径，否则编译会找不到 nccl.h
    export CUDA_HOME="${CUDA_HOME:-/usr/local/cuda-12.8}"
    export PATH="$CUDA_HOME/bin:$PATH"
    NCCL_HOME="${CONDA_PREFIX}/lib/python3.10/site-packages/nvidia/nccl"
    export CPATH="${NCCL_HOME}/include:${CPATH:-}"
    export LIBRARY_PATH="${NCCL_HOME}/lib:${LIBRARY_PATH:-}"
    export LD_LIBRARY_PATH="${NCCL_HOME}/lib:${CUDA_HOME}/lib64:${LD_LIBRARY_PATH:-}"

    pip install --no-build-isolation 'transformer-engine[pytorch,core_cu12]==2.14.1'
fi
python -c 'import transformer_engine; import transformer_engine.pytorch as te; \
print("[install] TE:", transformer_engine.__version__, "te.Linear:", hasattr(te, "Linear"))'

# apex（仅当 `apex` 参数显式传入时才编译）
if [[ "${1:-}" == "apex" ]]; then
    if ! python -c 'import apex' >/dev/null 2>&1; then
        echo "[install] === 编译 apex 源码（30+ min，需要 GPU 空闲）==="
        if [[ ! -d "${DEPS_DIR}/apex" ]]; then
            git clone https://github.com/NVIDIA/apex.git "${DEPS_DIR}/apex"
        fi
        (
            cd "${DEPS_DIR}/apex"
            pip install -v --disable-pip-version-check --no-cache-dir --no-build-isolation \
                --config-settings "--build-option=--cpp_ext" \
                --config-settings "--build-option=--cuda_ext" \
                ./
        )
    fi
fi

# ----------------------------------------------------------------------
# 8. 检验 (轻量)
# ----------------------------------------------------------------------
echo ""
echo "============================================================"
echo "[install] 环境装完。运行 'python tools/verify_env.py' 校验。"
echo "[install] 如果想装 apex（30+ min 编译，性能略提升）："
echo "[install]   bash scripts/00_install_env.sh apex"
echo "============================================================"
